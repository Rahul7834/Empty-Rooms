
strength += 0

def eat(self):
    pass