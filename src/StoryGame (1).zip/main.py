pain=0
hunger=0

def look():
    pass
  
