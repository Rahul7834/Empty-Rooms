intact = False

def smash(self):
    
    pass

def examine(self):
    
    pass