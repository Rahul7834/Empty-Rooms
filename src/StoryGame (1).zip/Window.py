open=False

def open(self):
    pass