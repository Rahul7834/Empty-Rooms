locked=False

def unlock(self)
def examine(self)
def kick(self)