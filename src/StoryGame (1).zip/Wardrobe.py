open = False

def open(self):
    pass

def examine(self):
    pass