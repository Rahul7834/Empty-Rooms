open = False

def examine(self):
    pass