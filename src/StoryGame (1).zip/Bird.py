alive = False
strength = 0

def kill(self):
    self.alive = False

def eat(self, food):
    self.strength += food